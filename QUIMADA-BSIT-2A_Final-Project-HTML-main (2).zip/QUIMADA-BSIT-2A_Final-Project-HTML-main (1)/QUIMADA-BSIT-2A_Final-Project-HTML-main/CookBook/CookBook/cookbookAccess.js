let users = JSON.parse(localStorage.getItem("users")) || [];


// Signup Logic
if (document.getElementById("signupForm")) {
  document.getElementById("signupForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("signupUsername").value;
    const email = document.getElementById("signupEmail").value;
    const password = document.getElementById("signupPassword").value;

    if (users.find((user) => user.username === username)) {
      alert("Username already exists!");
      return;
    }

    if (users.find((user) => user.email === email)) {
      alert("Email already exists!");
      return;
    }

    users.push({ username, email, password });
    localStorage.setItem("users", JSON.stringify(users));
    alert("Signup successful!");
    window.location.href = "CookeryLogin.html";
  });
}


// Login Logic
if (document.getElementById("loginForm")) {
  document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("loginUsername").value;
    const password = document.getElementById("loginPassword").value;

    const user = users.find(
      (user) => user.username === username && user.password === password
    );

    if (user) {
      alert("Login successful!");
      localStorage.setItem("loggedInUser", username);
      window.location.href = "Home.html";
    } else {
      alert("Invalid username or password!");
    }
  });
}

// Admin Page Logic
if (document.querySelector("#userTable")) {
  const userTableBody = document.querySelector("#userTable tbody");
  const editUserForm = document.getElementById("editUserForm");
  const editUsername = document.getElementById("editUsername");
  const editEmail = document.getElementById("editEmail");
  const editPassword = document.getElementById("editPassword");
  const saveUserButton = document.getElementById("saveUserButton");
  let editIndex = null;

  // Render Users in Table
  function renderUsers() {
    userTableBody.innerHTML = "";
    users.forEach((user, index) => {
      const row = document.createElement("tr");

      // Username
      const usernameCell = document.createElement("td");
      usernameCell.textContent = user.username;
      row.appendChild(usernameCell);

      // Email
      const emailCell = document.createElement("td");
      emailCell.textContent = user.email;
      row.appendChild(emailCell);

      // Password (Hidden)
      const passwordCell = document.createElement("td");
      passwordCell.textContent = "•••••••"; // Masked password
      row.appendChild(passwordCell);

      // Actions
      const actionsCell = document.createElement("td");

      // Edit Button
      const editBtn = document.createElement("button");
      editBtn.textContent = "Edit";
      editBtn.onclick = () => editUser(index);
      actionsCell.appendChild(editBtn);

      // Delete Button
      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "Delete";
      deleteBtn.onclick = () => deleteUser(index);
      actionsCell.appendChild(deleteBtn);

      row.appendChild(actionsCell);
      userTableBody.appendChild(row);
    });
  }

  // Edit User
  function editUser(index) {
    editIndex = index;
    editUsername.value = users[index].username;
    editEmail.value = users[index].email;
    editPassword.value = users[index].password;
    editUserForm.style.display = "block";
  }

  // Save Updated User
  saveUserButton.addEventListener("click", () => {
    if (editIndex !== null) {
      users[editIndex] = {
        username: editUsername.value,
        email: editEmail.value,
        password: editPassword.value,
      };
      localStorage.setItem("users", JSON.stringify(users));
      alert("User updated successfully!");
      editUserForm.style.display = "none";
      renderUsers();
    }
  });

  // Delete User
  function deleteUser(index) {
    users.splice(index, 1);
    localStorage.setItem("users", JSON.stringify(users));
    renderUsers();
  }

  renderUsers();
}



    function reiPage(){
        window.location.href = "https://web.facebook.com/tantrahend.h";
    }
   
    function  cassPage(){
        window.location.href = "https://web.facebook.com/kitty.hann.2024";
    }
    
    function  kitongPage(){
        window.location.href = "https://web.facebook.com/fritzkie241lhordgamerz";
    }

    function clarPage(){
        window.location.href = "https://web.facebook.com/clarence.simoran";
    }

    function emmanPage(){
      window.location.href = "https://web.facebook.com/sunshee19";
  }

    function dynaPage(){
    window.location.href = "https://web.facebook.com/dynarose.pepitoaragon";
}







