/*BISAYAN RECIPES YOW*/


/*VISAYAN APPETIZERS */

/*Dinakdakan*/

let  dinakdakanIP = 1;
const dinakDakan = [
    "Ingredients:<br><ul> <li>Grilled pork face, liver, and ears</li>   <li> Onions </li>    <li>Chili peppers</li>   <li>Vinegar</li>   <li>Salt and pepper to taste</li></ul>",
    "Procedures:<br> <ol> <li>Grill pork face, liver, and ears until cooked (20-30 mins).</li>  <li>Chop grilled meats, onions, and chili peppers finely.</li> <li>Mix chopped ingredients with vinegar, salt, and pepper.</li> <li>Serve and enjoy!</li>  </ol>",
    "Please click the button to proceed,"
 
];

function dinakdakanNext(){
  dinakdakanIP = (dinakdakanIP + 1) % dinakDakan.length;
  document.getElementById("dinakdakanIngproc").innerHTML = dinakDakan[dinakdakanIP];
}


/*Ngohiong*/
let  ngohiongIP = 1;
const ngohiong = [
    "Ingredients:<br><ul> <li> Ground pork</li>   <li> Vegetables (carrots, singkamas/jicama, green onions)</li>   <li>Spring roll wrappers</li>  <li>Various spices (garlic, pepper, soy sauce)</li>  <li>Dipping sauce ingredients (soy sauce, vinegar, garlic, sugar, pepper)</li>     </ul>",
    "Procedures:<br><ol>  <li>Mix ground pork, chopped vegetables, and spices.</li>   <li>Place mixture on spring roll wrappers and roll.</li>   <li>Deep-fry until golden brown (15 mins).</li>   <li> For the dipping sauce, mix soy sauce, vinegar, garlic, sugar, and pepper.</li>   <li>Serve Ngohiong with the dipping sauce.</li>   </ol>",
    "Please click the button to proceed,"
 
];

function ngohiongNext(){
  ngohiongIP = (ngohiongIP + 1) % ngohiong.length;
  document.getElementById("ngohiongIngproc").innerHTML = ngohiong[ngohiongIP];
}

/*Tinolang Tahong */
let  tinolangtahongIP  = 1;
const tinolangtahong = [
    "Ingredients:<br><ul>    <li>Mussels (tahong)</li>  <li>Ginger</li>  <li>Green papaya</li>  <li>Chili leaves</li>  <li>Onion</li>   <li>Fish sauce</li>   <li>Water</li>   </ul>",
    "Procedures:<br><ol>  <li> Clean and debeard mussels.</li>  <li>Sauté ginger and onions in a pot.</li>  <li>Add water, fish sauce, and bring to a boil.</li>  <li>Add mussels, green papaya, and chili leaves.</li>  <li> Simmer for 20-30 minutes.</li>  <li>Serve hot.</li>   </ol>",
    "Please click the button to proceed,"
 
];

function tinolangtahongNext(){
  tinolangtahongIP = (tinolangtahongIP+ 1) % tinolangtahong.length;
  document.getElementById("tinolangtahongIngproc").innerHTML = tinolangtahong[tinolangtahongIP];
}


/*Kinilaw Na Isda */

let  kinilawIP = 1;
const kinilawIsda = [
    "Ingredients:<br><ul> <li>Fresh fish</li>   <li>Vinegar</li>   <li>Lime juice</li>   <li>Ginger</li>   <li>Onion</li>   <li>Chili peppers</li>   <li>Salt and pepper to taste</li>    </ul>",
    "Procedures:<br><ol> <li> Mix fish, vinegar, and lime juice in a bowl.</li>  <li>Add ginger, onions, and chili peppers.</li>   <li>Season with salt and pepper.</li>   <li>Chill before serving (1-2 hours).</li>   </ol>",
    "Please click the button to proceed,"
 
];

function kinilawIsdaNext(){
  kinilawIP = (kinilawIP+ 1) % kinilawIsda.length;
  document.getElementById("kinilawisdaIngproc").innerHTML = kinilawIsda[kinilawIP];
}


/*Baked Scallops */
let bakedscallopsIP = 1;
const bakedScallops= [
    "Ingredients:<br><ul>  <li>Scallops in shells</li>   <li>Garlic</li>   <li>Butter</li>   <li>Cheese</li>   </ul>",
    "Procedures:<br><ol>  <li> Preheat the oven.</li>   <li>Mix scallops with minced garlic, butter, salt, and pepper.</li>   <li>Place scallops in shells, top with grated cheese.</li>   <li>Bake until cheese is melted and bubbly (15 mins).</li>   <li> Serve hot.</li>   </ol>",
    "Please click the button to proceed,"
 
];

function bakedScallopsNext(){
  bakedscallopsIP = (bakedscallopsIP + 1) % bakedScallops.length;
  document.getElementById("bakedScallopsIngproc").innerHTML = bakedScallops[bakedscallopsIP];
}








/*VISAYAN SALADS */

/*Ubad Salad */

let ubadIP = 1;
const ubadSalad = [
   "Ingredients:<br><ul>  <li>1 banana heart (ubad), finely sliced</li>  <li>2 tomatoes, diced</li>  <li>1 red onion, thinly sliced</li>  <li>2 salted eggs, sliced</li>  <li>1/4 cup calamansi juice</li>  <li>Salt and pepper to taste</li>  </ul>",
  "Proedures:<br><ol> <li>In a pot, bring water to a boil. Add a pinch of salt and blanch<br> the banana heart slices for 3-5 minutes or until tender. Drain and let it cool.</li>  <li>In a large bowl, combine the blanched banana heart, diced<br>tomatoes, sliced onions, and salted eggs.</li>   <li>Drizzle calamansi juice over the mixture and toss gently to combine.</li>   <li>Season with salt and pepper to taste.</li>   <li>Chill in the refrigerator for at least 30 minutes before serving.</li> </ol>",
   "Please click the button to proceed,"
 
];

function ubadNext(){
  ubadIP = (ubadIP + 1) % ubadSalad.length;
  document.getElementById("ubadIngproc").innerHTML = ubadSalad[ubadIP];
}

/*Bunga Sa Malunggay */

let bungalunggayIP = 1;
const bungalunggay = [
  "Ingredients:<br><ul>  <li>1 cup malunggay pods (drumsticks), cleaned and sliced</li>  <li>1/2 cup grated coconut</li>  <li>2 tomatoes, diced</li>  <li>Fish sauce to taste</li>   </ul>",
  "Proedures:<br><ol> <li>Blanch the moringa pods in boiling water for 2-3 minutes. Drain and let them cool.</li>  <li>In a bowl, combine the sliced moringa pods, grated coconut, and diced tomatoes.</li>   <li>Season the salad with fish sauce to taste.</li>   <li>Toss the ingredients until well combined.</li>   <li>Allow the flavors to meld by refrigerating for about 15-20 minutes before serving.</li>    </ol>",
  "Please click the button to proceed,"
];

function bungalunggayNext(){
  bungalunggayIP = (bungalunggayIP  + 1) % bungalunggay.length;
  document.getElementById("bungalunggayIngproc").innerHTML = bungalunggay[bungalunggayIP];
}

/*Labong Salad */
let labongIP = 1;
const  labongSalad = [
  "Ingredients:<br><ul>  <li>1 cup bamboo shoots, sliced</li>  <li>1/2 cup cooked shrimp, peeled and deveined</li>  <li>1 red onion, finely chopped</li>  <li>2 tablespoons calamansi juice</li>  <li>Salt and pepper to taste</li>   </ul>",
  "Proedures:<br><ol> <li>Boil the bamboo shoots until tender. Drain and let them cool.</li>  <li>In a bowl, combine the sliced bamboo shoots, cooked shrimp, and chopped red onion.</li>   <li>Drizzle calamansi juice over the mixture and toss gently.</li>   <li>Season with salt and pepper to taste. </li>  <li> Allow the salad to marinate in the refrigerator for at least 30 minutes before serving.</li>    </ol>",
  "Please click the button to proceed,"
];

function labongNext(){
 labongIP = (labongIP + 1) % labongSalad.length;
  document.getElementById("labongIngproc").innerHTML = labongSalad[labongIP];
}

/*Tinubong Na Saging */
let tinubongIP = 1;
const tinubongSaging = [
  "Ingredients:<br><ul>  <li> 4 ripe bananas, peeled and sliced</li>  <li>1 cup grated coconut</li>  <li>1/4 cup sugar</li>  <li>Pandan leaves (optional for flavor)</li>   </ul>",
  "Proedures:<br><ol> <li>Steam or boil the banana slices until tender. Drain and let them cool.</li>  <li>In a bowl, combine the steamed bananas, grated coconut, sugar, and pandan leaves (if using).</li>   <li>Gently mix the ingredients until well incorporated.</li>   <li>Allow the salad to cool in the refrigerator for about 1 hour before serving.</li>    </ol>",
  "Please click the button to proceed,"

  
];

function tinubongSagingNext(){
  tinubongIP = (tinubongIP + 1) % tinubongSaging.length;
  document.getElementById("tinubongSagingIngproc").innerHTML = tinubongSaging[tinubongIP];
}


/*Ampalaya ug Talaba bai */
let ampalayaTalabIP = 1;
const ampalayaTalaba = [
  "Ingredients:<br><ul>  <li>1 bitter melon (ampalaya), seeds removed and thinly sliced</li>  <li>1 cup fresh oysters, cleaned</li>  <li>2 tomatoes, diced</li>  <li>1 green mango, julienned</li>  <li>2 tablespoons fish sauce</li>  <li>1 tablespoon calamansi juice</li>  <li>1 teaspoon sugar</li>  <li>Red chili peppers (optional for spice)</li>  </ul>",
  "Proedures:<br><ol> <li>In a pan, briefly sauté the bitter melon slices until slightly tender. Let them cool.</li>  <li>In a bowl, combine the sautéed bitter melon, fresh oysters, diced<br> tomatoes, and julienned green mango.</li>   <li> In a small bowl, mix fish sauce, calamansi juice, sugar, and chopped chili peppers (if using).</li>   <li>Pour the dressing over the salad and toss gently to combine.</li>   <li>Refrigerate for at least 30 minutes before serving to enhance the flavors.</li>   </ol>",
   "Please click the button to proceed,"
];

function ampalayaTalabaNext(){
  ampalayaTalabIP = (ampalayaTalabIP + 1) % ampalayaTalaba.length;
  document.getElementById("ampalayaTalabaIngproc").innerHTML = ampalayaTalaba[ampalayaTalabIP];

}






/*VISAYAN SOUPS */

/*Halaan Soup yow */

let halaanIP = 1;
const halaanSoup = [
   "Ingredients:<br><ul>  <li>2 lbs fresh halaan (clams)</li>  <li>1 tablespoon ginger, minced</li>  <li>2 cloves garlic, minced</li>  <li> 1 onion, chopped</li>  <li>3 tablespoons fish sauce</li>  <li>1/2 teaspoon pepper</li>  <li>4 cups water</li>  <li>Green onions for garnish</li>    </ul>",
   "Procedures:<br><ol>  <li>Scrub the clams under running water to remove sand.</li>    <li>Soak them in saltwater for 30 minutes.</li>    <li>Rinse again and drain.</li>    <li>In a pot, sauté ginger, garlic, and onions until aromatic.</li>    <li> Add the cleaned clams to the pot.</li>    <li>Pour in 4 cups of water and bring to a boil.</li>    <li> Stir in fish sauce and pepper.</li>    <li>Adjust the seasoning to your taste.</li>  <li>Reduce heat to a simmer and cook until clams open. Discard any<br> unopened clams.</li>    <li>Garnish with chopped green onions.</li>   <li>Serve hot and enjoy your Halaan Soup!</li>      </ol>",
   "Please click the button to proceed,"

];

function halaanNext(){
  halaanIP = (halaanIP + 1) % halaanSoup.length;
  document.getElementById("halaanIngproc").innerHTML = halaanSoup[halaanIP];
}

/*Linagpang nga isda */

let linagpangIsdaIP = 1;
const linagpangIsda = [
   "Ingredients:<br><ul>  <li>2 lbs fish (tilapia or any local fish)</li>  <li>2 stalks lemongrass, pounded</li>  <li>1 tablespoon ginger, sliced</li>  <li>1 onion, chopped</li>  <li>Salt and pepper to taste</li>  <li>4 cups water</li>  <li>Green chilies (optional)</li>     </ul>",
   "Procedures:<br><ol>  <li>Clean the fish and rub with salt.</li>    <li>In a pot, combine fish, lemongrass, ginger, and onions.</li>    <li>Add enough water to cover the fish and bring to a boil.</li>    <li>Season with salt and pepper. Adjust to taste.</li>    <li>Simmer until the fish is cooked through.</li>    <li>Optionally, add green chilies for a spicy kick.</li>    <li>Serve hot and enjoy Linagpang nga Isda!</li>       </ol>",
   "Please click the button to proceed,"

];

function linagpangIsdaNext(){
  linagpangIsdaIP  = (linagpangIsdaIP + 1) % linagpangIsda.length;
  document.getElementById("linagpangIsdaIngproc").innerHTML = linagpangIsda[linagpangIsdaIP];
}


/*Linagpang nga manok */

let linagpangManokIP= 1;
const linagpangManok = [
   "Ingredients:<br><ul>  <li>Chicken pieces</li>  <li>2 stalks lemongrass, pounded</li>  <li>1 tablespoon ginger, sliced</li>  <li>1 onion, chopped</li>  <li>Salt and pepper to taste</li>  <li>Green chilies (optional)</li>    </ul>",
   "Procedures:<br><ol>  <li>In a pot, combine chicken, lemongrass, ginger, and onions.</li>    <li>Add enough water to cover the chicken and bring to a boil.</li>    <li>Season with salt and pepper. Adjust to taste.</li>    <li>Simmer until the chicken is tender.</li>    <li>Optionally, add green chilies for extra flavor.</li>    <li>Serve hot and enjoy Linagpang nga Manok!</li>      </ol>",
   "Please click the button to proceed,"

];

function linagpangManokNext(){
  linagpangManokIP = (linagpangManokIP + 1) % linagpangManok.length;
  document.getElementById("linagpangManokIngproc").innerHTML = linagpangManok[linagpangManokIP];
}

/*Utan Bisaya */
let utanIP = 1;
const utanBisaya = [
   "Ingredients:<br><ul>  <li>Assorted local vegetables (e.g., string beans, eggplant, squash, okra)</li>  <li>Shrimp paste (bagoong)</li>  <li>Salt</li>  <li>Seasonings(Any Brand)</li>     </ul>",
   "Procedures:<br><ol>  <li>Wash and chop the assorted vegetables into bite-sized pieces.</li>    <li>In a pot, bring water to a boil.</li>    <li>Add the vegetables to the boiling water.</li>    <li>Cook until the vegetables are tender but not overcooked.</li>    <li>Stir in shrimp paste (bagoong) to taste. Adjust according to your preference.</li>    <li>Allow the flavors to meld by simmering for a few more minutes.</li>    <li>Serve hot and enjoy Utan Bisaya!</li>      </ol>",
   "Please click the button to proceed,"

];

function otanNext(){
  utanIP = (utanIP + 1) % utanBisaya.length;
  document.getElementById("otanIngproc").innerHTML = utanBisaya[utanIP];
}

/**Lansiao */
let lansiaoIP = 1;
const lansiaosiao = [
   "Ingredients:<br><ul>  <li>Pork liver, sliced</li>  <li>Pork heart, sliced</li>  <li>Pork kidneys, sliced</li>  <li>Pork intestines, cleaned and sliced</li>  <li>Pork meat, sliced</li>  <li>Miki noodles (or egg noodles)</li>  <li>Garlic, minced</li>  <li>Onion, chopped</li>  <li>Fish sauce, salt, and pepper to taste</li>  <li>Hard-boiled eggs (optional)</li>  <li>Chicharrón (pork cracklings) for topping</li>   </ul>",
   "Procedures:<br><ol>  <li>In a pot, boil the pork liver, heart, kidneys, intestines, and meat until tender.</li>    <li>Cook Miki noodles according to package instructions.</li>    <li>In a separate pan, sauté garlic and onions until aromatic.</li>    <li>Add sautéed aromatics to the pot of boiled meat.</li>    <li>Season with fish sauce, salt, and pepper to taste.</li>    <li>Allow the flavors to meld by simmering for a few more minutes.</li>    <li>Serve the soup over cooked noodles.</li>    <li>Top with hard-boiled eggs and chicharrón.</li>    <li>Serve hot and enjoy Lansiao!</li>   </ol>",
   "Please click the button to proceed,"

];

function lansiaoNext(){
  lansiaoIP = (lansiaoIP + 1) % lansiaosiao.length;
  document.getElementById("lansiaoIngproc").innerHTML = lansiaosiao[lansiaoIP];
}







/*VISAYAN SIDE DISHES:D */

/*Adobo Sa Dilaw */
let dilawIP = 1;
const adoboDilaw = [
   "Ingredients:<br><ul> <li>1 kg pork belly, cut into cubes</li>   <li> 1 cup turmeric powder (dilaw)</li>     <li>1 head garlic, minced</li>     <li>1 onion, chopped</li>     <li>1 cup vinegar</li>     <li>1/2 cup soy sauce</li>     <li>2 bay leaves</li>     <li>Salt and pepper to taste</li>     </ul>",
   "Procedures:<br><ol> <li>Marinate pork in turmeric powder, soy sauce, vinegar, garlic, onion, bay<br> leaves, salt, and pepper for at least 30 minutes.</li>   <li>In a pot, cook marinated pork until tender. Add water if needed.</li>     <li>Simmer until the sauce thickens.</li>       </ol>",
   "Please click the button to proceed,"

];

function dilawNext(){
  dilawIP = (dilawIP + 1) % adoboDilaw.length;
  document.getElementById("dilawIngproc").innerHTML = adoboDilaw[dilawIP];
}

/**Puso or Hanging rice daw */
let pusoIP = 1;
const pusoRice = [
   "Ingredients:<br><ul> <li>Glutinous rice</li>   <li> Woven coconut leaves for packaging</li>     </ul>",
   "Procedures:<br><ol> <li>Wash glutinous rice.</li>   <li>Fill woven coconut leaves with washed rice.</li>     <li>Steam until cooked.</li>    </ol>",
   "Please click the button to proceed,"

];

function pusoNext(){
  pusoIP = (pusoIP + 1) % pusoRice.length;
  document.getElementById("pusoIngproc").innerHTML = pusoRice[pusoIP];
}


/**Sinugba nga Baboy */
let sinugbaboyIP = 1;
const sinugBaboy = [
   "Ingredients:<br><ul> <li>1 kg pork belly, sliced thinly</li>   <li>1 cup soy sauce</li>     <li>1/2 cup calamansi juice</li>     <li>5 cloves garlic, minced</li>     <li>Salt and pepper to taste</li>       </ul>",
   "Procedures:<br><ol> <li>Marinate pork in soy sauce, calamansi juice, garlic, salt, and pepper<br> for at least 30 minutes.</li>   <li> Grill until fully cooked.</li>   </ol>",
   "Please click the button to proceed,"

];

function sugbaboyNext(){
 sinugbaboyIP = (sinugbaboyIP + 1) % sinugBaboy.length;
  document.getElementById("sugbaboyIngproc").innerHTML = sinugBaboy[sinugbaboyIP];
}

/**Inasal Na  Manok */
let asalManokIP = 1;
const asalNaManok = [
   "Ingredients:<br><ul> <li>1 whole chicken, cut into serving pieces</li>   <li>1 cup coconut vinegar</li>     <li>1/2 cup soy sauce</li>     <li>1 head garlic, minced</li>     <li>1 thumb-sized ginger, minced</li>     <li>1 tsp annatto powder (achuete)</li>     <li>Salt and pepper to taste</li>        </ul>",
   "Procedures:<br><ol> <li>Marinate chicken in coconut vinegar, soy sauce, garlic, ginger, annatto<br> powder, salt, and pepper for at least 1 hour.</li>   <li>Grill until chicken is cooked and has a nice char.</li>     </ol>",
   "Please click the button to proceed,"

];

function manokInasalNext(){
  asalManokIP = (asalManokIP + 1) % asalNaManok.length;
  document.getElementById("manokInasalIngproc").innerHTML = asalNaManok[asalManokIP];
}


/*Paklay */

let paklayIP = 1;
const paklayS = [
   "Ingredients:<br><ul> <li>1 kg pork intestines, cleaned and sliced</li>   <li>1 cup pork liver, sliced</li>     <li>1 cup vinegar</li>     <li>1 cup soy sauce</li>     <li>5 cloves garlic, minced</li>     <li>1 onion, chopped</li>     <li>2 thumbs ginger, sliced</li>     <li>3-4 pieces bay leaves</li>     <li>Salt and pepper to taste</li>    </ul>",
   "Procedures:<br><ol> <li>Boil pork intestines until tender. Drain and set aside.</li>   <li> In a pot, combine pork<br> intestines, pork liver, vinegar, soy sauce, garlic, onion, ginger, bay leaves, salt, and pepper.</li>     <li>Simmer until flavors meld and sauce thickens.</li>  </ol>",
   "Please click the button to proceed,"

];

function paklayNext(){
  paklayIP = (paklayIP + 1) % paklayS.length;
  document.getElementById("paklayIngproc").innerHTML = paklayS[paklayIP];
}




/**VISAYAN DESSERTS */

/*Binignits */

let binignitIP = 1;
const binignight = [
  "Ingredients:<br>  <ul>  <li>1 cup glutinous rice balls</li>   <li>1 cup sweet potatoes, cubed</li>   <li>1 cup taro, cubed</li>   <li>1 cup saba bananas, sliced</li>   <li>1 cup jackfruit, sliced</li>   <li> 1 cup coconut milk</li>   <li>1 cup water</li>   <li>1 cup sugar</li>   <li>Banana leaves for serving</li>     </ul>",
  "Procedures:<br><ol>   <li>In a pot, combine coconut milk and water. Bring to a simmer.</li>  <li>Add glutinous rice balls, sweet potatoes, taro, saba bananas, and jackfruit to the pot.</li>   <li>Stir in sugar and let it simmer until the ingredients are tender.</li>   <li>Serve hot in banana leaf-lined bowls.</li>       </ol>",
  "Please click the button to proceed,"

];

function binignitNext(){
  binignitIP = (binignitIP + 1) % binignight.length;
  document.getElementById("binignitIngproc").innerHTML = binignight[binignitIP];
}

/**BUDBOD KABOG */
let kabogIP = 1;
const budbodKabog = [
  "Ingredients:<br>  <ul>  <li> 2 cups kabog (millet) grains</li>   <li>2 cups glutinous rice</li>   <li>2 cups coconut milk</li>   <li> Banana leaves for wrapping</li>    </ul>",
  "Procedures:<br><ol>   <li>Rinse kabog grains and glutinous rice separately.</li>  <li>Mix kabog, glutinous rice, and coconut milk in a bowl.</li>   <li>Spoon the mixture onto banana leaves and wrap into cylindrical shapes.</li>   <li>Steam the wrapped rice cakes until cooked.</li>   <li>Serve with ripe mango slices.</li>     </ol>",
  "Please click the button to proceed,"

];

function kabogNext(){
  kabogIP = (kabogIP + 1) % budbodKabog.length;
  document.getElementById("kabogIngproc").innerHTML = budbodKabog[kabogIP];
}

/**BAYE-BAYE */
let bayeIP = 1;
const bayebaye = [
  "Ingredients:<br>  <ul>  <li>2 cups grated cassava</li>   <li>1 cup coconut milk</li>   <li>1 cup sugar</li>   <li>Banana leaves for wrapping</li>    </ul>",
  "Procedures:<br><ol>   <li>Combine grated cassava, coconut milk, and sugar in a bowl.</li>  <li>Spoon the mixture onto banana leaves and shape into small cakes.</li>   <li>Steam the wrapped cakes until cooked.</li>   <li>Allow to cool before serving.</li>      </ol>",
  "Please click the button to proceed,"

];

function bayebayeNext(){
  bayeIP = (bayeIP + 1) % bayebaye.length;
  document.getElementById("bayebayeIngproc").innerHTML = bayebaye[bayeIP];
}


/**Binangkal */
let binangkalIP = 1;
const biNangkal = [
  "Ingredients:<br>  <ul>  <li>2 cups glutinous rice flour</li>   <li>1 cup brown sugar</li>   <li>1/2 cup water</li>   <li>Sesame seeds for coating</li>   <li>Oil for frying</li>   </ul>",
  "Procedures:<br><ol>   <li>Mix glutinous rice flour, brown sugar, and water to form a dough.</li>  <li>Shape the dough into small balls.</li>   <li>Roll the balls in sesame seeds until coated.</li>   <li>Deep fry until golden brown.</li>   <li>Drain excess oil on paper towels before serving.</li>     </ol>",
  "Please click the button to proceed,"

];

function binangkalNext(){
  binangkalIP = (binangkalIP + 1) % biNangkal.length;
  document.getElementById("binangkalIngproc").innerHTML = biNangkal[binangkalIP];
}

 /*Tupig*/
let tupigIP = 1;
const tupigpig = [
  "Ingredients:<br>  <ul>  <li>2 cups glutinous rice</li>   <li>1 cup grated coconut</li>   <li>1 cup molasses</li>   <li>Sesame seeds for coating</li>   <li>Banana leaves for wrapping</li>      </ul>",
  "Procedures:<br><ol>   <li>Mix glutinous rice, grated coconut, and molasses in a bowl.</li>  <li>Spoon the mixture onto banana leaves and shape into flat rectangles.</li>   <li>Grill until the edges are crisp and golden.</li>   <li>Roll in sesame seeds while still warm.</li>   <li>Allow to cool before serving.</li>     </ol>",
  "Please click the button to proceed,"

];

function tupigNext(){
  tupigIP = (tupigIP + 1) % tupigpig.length;
  document.getElementById("tupigIngproc").innerHTML = tupigpig[tupigIP];
}


function searchSection(){
  const query = document.getElementById('search').value.toLowerCase().trim();
  
  if(query === "")
  return;
  const sections = document.querySelectorAll('section');
  let matchFound = false;

  //Removing previous higlights!

  document.querySelectorAll('mark').forEach((mark) => mark.outerHTML = mark.textContent);


 sections.forEach((section) => {
  const texts = section.querySelectorAll('h2, p');
  texts.forEach((text)=> {
      const originalText = text.textContent;
      const newText = originalText.replace(new RegExp(query, 'gi'), match => `<mark>${match}</mark>`);

      if(newText!==originalText){
          text.innerHTML = newText;
          text.parentNode.scrollIntoView({behavior: 'smooth'});
          matchFound = true;
      }
  });
 });

 if(!matchFound){
  document.getElementById('result').innerHTML = "Word doesn't match.";



  document.querySelectorAll('mark').forEach((mark) => mark.outerHTML = mark.textContent);
  
 } else {
  document.getElementById('result').innerHTML = "";
 }
    
}




