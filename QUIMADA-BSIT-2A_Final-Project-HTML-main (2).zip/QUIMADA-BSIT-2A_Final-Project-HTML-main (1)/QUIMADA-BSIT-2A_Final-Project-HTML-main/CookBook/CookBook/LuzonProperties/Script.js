/*LUZON APPETIZERS */

/*Tokwat Baboy*/
let tokwaIP = 1;
const tokwatbaboy = [
 
  "Ingredients:<br> <ul> <li>1  block (about 300g) firm tofu, cubed.</li>   <li>1/2 pound pork belly, boiled and sliced into thin strips.</li>   <li>1 onion, peeled and sliced thinly</li>   <li>2 cloves garlic, minced</li>   <li>1 red chili, chopped(optional)</li>   <li>2 tablespoons soy sauce</li>   <li>2 tablespoons vinegar</li>   <li>Salt and pepper to taste</li>   <li>Cooking oil for frying</li>   <li>Green onions and fried garlic for garnish</li>  </ul>",
  "Procedures:<br> <ol> <li>Fry the tofu until golden brown. Set aside.</li>  <li>In a separate pan, saute garlic and onions until<br>fragrant.</li>  <li>Add the boiled pork belly slices and cook until<br>lightly browned</li>   <li>Add the fried tofu cubes and chopped red chili(if<br>using)</li>  <li>Pour in soy sauce and vinegar. Season with salt <br> and pepper to taste.</li>  <li>Stir and let it simmer for a few minutes.</li>  <li>Garnish with green onionns and fried garlic.</li>  <li>Serve Warm and enjoy this delightful tokwat baboy appetizer!</li> </ol>",
  "Please click the button to proceed,"

];

function tokwatNext(){
  tokwaIP = (tokwaIP + 1) % tokwatbaboy.length;
  document.getElementById("tokwatIngproc").innerHTML = tokwatbaboy[tokwaIP];
}

/*Sisig*/
let sisigIP = 1;
const sisig = [
 "Ingredients:<br> <ul>  <li>1/2 pound pork face (face, meat, eats, snout), boiled<br> and chopped</li>     <li>1/4 pound pork liver, boilded and chopped</li>  <li>1 onion, minced </li>    <li>3 cloves garlic, minced </li>    <li>2 red chilies, minced</li>    <li>1/4 cup calamansi juice(or lemon juice)</li>    <li>3 tablespoons soy sauce</li>    <li>Salt and pepper to taste</li>    <li>Cooing oil for sauteing</li>    <li>Mayonnaise(optional)</li>    <li>Egg, fried or poached(optional)</li>   </ul>",
 "Procedures:<br> <ol> <li>In a pan, heat oil and saute garlic and onions until<br>soft.</li>   <li>Add chopped pork face and liver. Cook until<br>browned.</li>   <li>Pour in soy sauce and calamansi juice. Mix well.</li>   <li>Season with salt and pepper according to taste.</li>   <li>Add minced red chillies for extra spice.</li>  <li>Optional: Add mayonnaise for a creamy texture.</li>   <li>Serve on a sizzling plate. Top with a fried or poachead egg if desired.</li>   <li>Garnish with additional minced onions and chillies.</li>   <li>Enjoy Sisig as a flavorful and sizzling appetizer!</li>  </ol>",
 "Please click the button to proceed,"
  
];

function sisigNext(){
  sisigIP = (sisigIP + 1) % sisig.length;
  document.getElementById("sisigIngproc").innerHTML = sisig[sisigIP];
}

/*Adidas*/
let adidasIP = 1;
const adidas = [
 "Ingredients:<br> <ul>  <li>Chicken feet, cleaned</li>  <li>1 cup soy sauce</li>   <li>1/2 cup vinegar</li>   <li>1 teaspoon peppercorns</li>   <li>3 bay leaves</li>   <li>4 cloves garlic, minced</li>   <li>1 onion, chopped</li>   <li>Cooking oil for grilling</li> </u>",
 "Procedures:<br> <ol> <li> In a bowl, combine soy sauce, vinegar, peppercorns, bay leaves, minced garlic,<br> and chopped onion to create the marinade.</li>   <li>Marinate the cleaned chicken feet in the mixture for at least 2 hours or overnight<br> in the refrigerator.</li>   <li>Grill the marinated chicken feet until fully cooked and has a nice char.</li>  <li>Serve warm as a flavorful and unique appetizer.</li>  </ol>",
 "Please click the button to proceed,"
];

function adidasNext(){
  adidasIP = (adidasIP + 1) % adidas.length;
  document.getElementById("adidasIngproc").innerHTML =  adidas[adidasIP];
}

/*Kwek-kwek*/
let kwekIP = 1;
const kwekkwek = [
  "Ingredients:<br> <ul> <li>Quail eggs, hard-boiled and peeled</li> <li>1 cup orange-colored batter (made from flour, water, annatto <br>powder, salt, and pepper)</li> <li>Cooking oil for deep-frying</li> <li>Vinegar and soy sauce or achara (pickled green papaya) for dipping</li>  </ul>",
  "Procedures:<br> <ol> <li>Dip the hard-boiled quail eggs into the orange-colored batter, ensuring<br> they are fully coated.</li>  <li>Heat cooking oil in a deep pan or fryer.</li> <li>Deep-fry the coated quail eggs until golden brown and crispy.</li> <li>Remove from the oil and drain excess oil on paper towels.</li> <li>Serve the kwek-kwek with vinegar and soy sauce for dipping or with achara for added flavor.</li> </ol>",
  "Please click the button to proceed,"
];

function kwekNext(){
  kwekIP = (kwekIP + 1) % kwekkwek.length;
  document.getElementById("kwekIngproc").innerHTML =  kwekkwek[kwekIP];
}

/*BetaMax*/

let betamaxIP = 1;
const betamax= [
  "Ingredients: <ul> <li>Chicken or pork blood, cleaned and cut into<br> rectangular or cylindrical shapes</li>  <li>1 cup vinegar</li>  <li>1/2 cup soy sauce</li>   <li>1 teaspoon garlic, minced</li>   <li>1 teaspoon sugar</li>  <li>Skewers for grilling</li>  </ul>",
  "Procedures: <ol> <li>In a bowl, combine vinegar, soy sauce, minced garlic, and sugar<br> to create the marinade.</li>  <li>Marinate the cleaned and cut chicken or pork blood in the mixture<br> for at least 30 minutes to an hour.</li> <li>Thread the marinated blood onto skewers, similar to the appearance of Betamax tapes.</li> <li>Grill the skewered blood until fully cooked and has a nice char.</li> <li>Serve warm as a unique and flavorful appetizer.</li>  </ol>",
  "Please click the button to proceed,"
];

function betamaxNext(){
  betamaxIP = (betamaxIP + 1) % betamax.length;
  document.getElementById("betamaxIngproc").innerHTML =  betamax[betamaxIP];
}

/*SALADS*/

/*Pako Salad*/

let pakoIP = 1;
const pakoSalad= [
  "Ingredients:<br><ul> <li>Fiddlehead ferns (pako), blanched</li>  <li>Tomatoes, sliced</li>   <li>Salted eggs, sliced</li>  <li>Onions, thinly sliced</li>  <li>Vinegar or calamansi juice</li>  <li>Salt and pepper to taste</li> </ul>",
  "Procedures:<br> <ol>  <li> Blanch fiddlehead ferns and let them cool.</li>  <li> In a bowl, combine blanched fiddlehead ferns, sliced tomatoes, salted eggs, and thinly<br> sliced onions.</li>   <li>Season with vinegar or calamansi juice, adjusting to taste.</li>    <li>Add salt and pepper to enhance the flavors.</li>    <li>Gently toss the ingredients until well combined.</li>    <li>Serve this Pako Salad for a refreshing and nutritious dish. </li></ol>",
  "Please click the button to proceed,"
];

function pakoNext(){
  pakoIP = (pakoIP + 1) % pakoSalad.length;
  document.getElementById("pakoIngproc").innerHTML =  pakoSalad[pakoIP];
}

/*Lato Salad*/

let latoIP = 1;
const latoSalad= [
  "Ingredients:<br><ul> <li>Lato (seaweed)</li>  <li>Tomatoes, diced</li>   <li>Onions, thinly sliced</li>  <li>Vinegar or calamansi juice</li>  <li>Salt and pepper to taste</li></ul>",
  "Procedures:<br><ol>  <li> Rinse the lato (seaweed) thoroughly and drain excess water.</li>  <li>In a bowl, combine the lato with diced tomatoes and thinly sliced onions.</li>  <li> Season with vinegar or calamansi juice, adjusting to taste.</li>  <li>Add salt and pepper for additional flavor.</li>  <li>Gently toss the ingredients until well mixed.</li>  <li>Serve this Lato Salad as a unique and refreshing side dish.</li> </ol>",
  "Please click the button to proceed,"

];

function latoNext(){
  latoIP = (latoIP+ 1) % latoSalad.length;
  document.getElementById("latoIngproc").innerHTML =  latoSalad[latoIP];
}

/*Kangkong Salad*/

let kangkongIP = 1;
const kangkongSalad= [
  "Ingredients:<br><ul> <li>Kangkong (water spinach), blanched</li>  <li>Tomatoes, sliced</li> <li>Salted eggs, sliced</li> <li>Onions, thinly sliced</li> <li>Vinegar or calamansi juice</li> <li>Salt and pepper to taste</li></ul>",
  "Procedures:<br><ol>  <li>Blanch water spinach and let it cool.</li>  <li> In a bowl, combine blanched water spinach, sliced tomatoes, salted eggs, and thinly<br> sliced onions.</li> <li>Season with vinegar or calamansi juice, adjusting to taste.</li> <li>Add salt and pepper for flavor balance.</li> <li>Gently toss the ingredients until well combined.</li> <li>Serve this Kangkong Salad for a simple and nutritious side dish.</li></ol>",
  "Please click the button to proceed,"
];

function kangkongNext(){
  kangkongIP = (kangkongIP+ 1) % kangkongSalad.length;
  document.getElementById("kangkongIngproc").innerHTML =  kangkongSalad[kangkongIP];
}

/*LUZON DESSERTS*/

/*Halo-Halo */

let haloIP = 1;
const halohalo= [
  "Ingredients:<br><ul>  <li>Crushed ice</li>  <li>Sweetened fruits (such as jackfruit, banana, and langka/jackfruit)</li>  <li>Sweetened beans (red beans, garbanzos/chickpeas)</li>  <li>Sweetened saba (cooking bananas)</li>  <li>Nata de coco (coconut gel)</li>  <li>Kaong (sugar palm fruit)</li>  <li> Macapuno (sweetened shredded coconut)</li>  <li>Leche flan (see recipe below)</li>  <li>Ube halaya (purple yam jam)</li>  <li>Shaved ice</li>  <li>Evaporated milk</li>  <li>Leche flan or ube ice cream (optional)</li></ul>",
  "Procedures:<br><ol>  <li> In a tall glass or bowl, layer the crushed ice.</li>  <li>Add the sweetened fruits, beans, saba, nata de<br> coco, kaong, and macapuno.</li>  <li>Add a layer of leche flan and ube halaya.</li>  <li>Top with shaved ice.</li>  <li>Pour evaporated milk over the ice until fully covered.</li>  <li>Optional: Add a scoop of leche flan or ube ice cream on top.</li>  <li>Serve with a long spoon and mix well before eating.</li>   </ol>",
  "Please click the button to proceed,"
];

function haloNext(){
  haloIP = (haloIP + 1) % halohalo.length;
  document.getElementById("haloIngproc").innerHTML =  halohalo[haloIP];
}


/*Leche flan*/
let lecheIP = 1;
const lecheflan= [
  "Ingredients:<br><ul> <li>10 egg yolks</li>  <li>1 can (300 ml) condensed milk</li>  <li> 1 can (370 ml) evaporated milk</li>   <li>1 teaspoon vanilla extract</li>  <li> 1 cup sugar (for caramelizing)</li>  </ul>",
  "Procedures:<br><ol>  <li>Preheat your steamer over medium heat.</li>    <li> In a mixing bowl, combine the egg yolks, condensed milk, evaporated milk, and vanilla<br>extract. Mix well but avoid incorporating too much air.</li>     <li>Strain the mixture to achieve a smooth consistency.</li>     <li>In a separate pan, caramelize the sugar over low to medium heat until it turns golden brown. Pour the<br>caramelized sugar into the leche flan mold, coating the bottom evenly.</li>     <li>Pour the egg mixture into the mold on top of the caramelized sugar.</li>     <li>Cover the mold with aluminum foil and steam for about 30-40 minutes or until<br> the leche flan is set.</li>     <li>Allow it to cool before refrigerating for a few hours or overnight.</li>     <li>Once chilled, run a knife around the edges of the mold, invert<br>it onto a serving plate, and serve.</li> </ol>",
  "Please click the button to proceed,"
];

function lecheNext(){
  lecheIP = (lecheIP+ 1) % lecheflan.length;
  document.getElementById("lecheIngproc").innerHTML =  lecheflan[lecheIP];
}

/*Bibingka*/

let bingkaIP = 1;
const bibingka= [
  "Ingredients:<br><ul> <li>2 cups rice flour</li>   <li>1 cup all-purpose flour</li>    <li>3 teaspoons baking powder</li>    <li>1/2 teaspoon salt</li>    <li>1 1/2 cups coconut milk</li>   <li>1/2 cup water</li>   <li>3/4 cup sugar</li>   <li>3 eggs</li>   <li>Butter or margarine, softened</li>   <li>Salted egg, sliced</li>   <li>Grated coconut (optional)</li>   </ul>",
  "Procedures:<br><ol> <li>Preheat your oven to 375°F (190°C).</li>  <li>In a bowl, combine rice flour, all-purpose flour, baking powder, and salt.</li>   <li> In another bowl, mix coconut milk, water, sugar, and eggs until well combined.</li>    <li>Gradually add the wet ingredients to the dry ingredients, stirring until smooth.</li>     <li>Grease the bibingka molds with butter or margarine.</li>    <li>Pour the batter into the molds until halfway full.</li>     <li>Bake in the preheated oven for about 15-20 minutes or until the top is set.</li>    <li>Place slices of salted egg on top and continue baking for another 10-15 minutes<br> or until a toothpick inserted comes out clean.</li>  <li>Optional: Brush the tops with butter and sprinkle with grated coconut before serving.</li>  </ol>",
  "Please click the button to proceed,"
];

function bingkaNext(){
  bingkaIP = (bingkaIP+ 1) % bibingka.length;
  document.getElementById("bingkaIngproc").innerHTML =  bibingka[bingkaIP];
}

/*Puto Bumbong */

let bumbongIP = 1;
const putobumbong = [
  "Ingredients:<br><ul> <li>2 cups glutinous rice</li>   <li>1/2 cup purple yam (ube), grated</li>   <li>Water for soaking and grinding</li>   <li>Banana leaves, cut into rectangles</li>   <li>Butter or margarine</li>   <li>Grated coconut and sugar for serving</li> </ul>",
  "Procedures:<br><ol> <li>Soak the glutinous rice in water for at least 4 hours or overnight.</li>  <li>Drain the rice and grind it with grated purple yam, adding water as needed to make a smooth batter.</li>    <li>Prepare the puto bumbong steamer. Place the banana leaves in the steamer, and<br> fill each bamboo tube with the rice batter.</li>    <li>Steam for about 10-15 minutes or until the rice cakes are cooked.</li>   <li>Remove the puto bumbong from the bamboo tubes.</li>   <li>Brush each rice cake with butter or margarine.</li>   <li>Serve with grated coconut and sugar on the side.</li> </ol>",
  "Please click the button to proceed,"
];

function bumbongNext(){
  bumbongIP = (bumbongIP + 1) % putobumbong.length;
  document.getElementById("bumbongIngproc").innerHTML =  putobumbong[bumbongIP];
}

/*Sans Rival */

let sansIP = 1;
const sansrival = [ 
  "Ingredients:<br>Meringue:<ul>   <li>1 cup unsalted butter, softened</li>    <li>1 cup granulated sugar</li>   <li>1 teaspoon vanilla extract</li>   <li>4 large egg whites</li>  <li>1 cup chopped cashews</li> </ul>",
  "Butter Cream:<br> <ul>  <li>1 cup unsalted butter, softened</li>  <li>1 cup powdered sugar</li>  <li>1 teaspoon vanilla extract</li>  <li>1 cup chopped cashews (for assembly)</li>  </ul>",
  "Procedures:<br>Meringue:<br> <ol> <li>Preheat your oven to 325°F (163°C). Line baking sheets with parchment paper.</li>  <li>In a bowl, cream together the softened butter, sugar, and<br> vanilla extract until light and fluffy.</li>    <li>In a separate clean, dry bowl, beat the egg whites until stiff peaks form.</li>    <li>Gently fold the beaten egg whites into the butter mixture.</li>    <li>Fold in the chopped cashews.</li>    <li>Divide the mixture into three equal parts and spread each part<br>onto the prepared baking sheets, forming three layers.</li>    <li>Bake in the preheated oven for about 20-25 minutes or until the meringue<br> is golden brown.</li>    <li>Allow the meringue layers to cool completely.</li> </ol>",
  "Butter Cream(procedures):<br> <ol> <li>In a bowl, beat together the softened butter, powdered sugar, and vanilla<br> extract until smooth and creamy.</li> </ol>",
  "Assembly:<br> <br><ol> <li>Place one meringue layer on a serving plate.</li>   <li> Spread a layer of buttercream on top of the meringue.</li>   <li>Repeat the process, stacking the meringue layers with buttercream in between.</li>   <li>Frost the top and sides of the assembled cake with the remaining buttercream.</li>   <li>Press chopped cashews onto the sides of the cake for decoration.</li>   <li> Chill the Sans Rival in the refrigerator for a few hours or overnight to set.</li>   <li>Slice and serve chilled.</li>  </ol>",
  "Please click the button to proceed,"
];

function sansNext(){
  sansIP = (sansIP + 1) % sansrival.length;
  document.getElementById("sansIngproc").innerHTML =  sansrival[sansIP];
}



/*LUZON'S SOUP MAIN DISHES */

/*Sinigang na baboy */

let sinbaboyIP = 1;
const sinigangbaboy = [ 
  "Ingredients:<br><ul>  <li>Pork ribs or belly</li>   <li>Tamarind (sampaloc) for souring</li>   <li>Water spinach (kangkong)</li>   <li>Radish (labanos)</li>   <li>String beans (sitaw)</li>   <li>Eggplant (talong)</li>   <li>Green chili peppers</li>   <li>Fish sauce (patis)</li> </ul>",
  "Procedures:<br><ol>  <li>Boil pork in tamarind-infused broth for 30-45 minutes until tender.</li>  <li> Add vegetables - water spinach, radish, string<br> beans, and eggplant. Include green chili peppers.</li>   <li>Season with fish sauce (patis) to taste.</li>   <li>Simmer for an additional 15-20 minutes.</li>   <li>Serve hot.</li>   </ol>",
  "Please click the button to proceed,"
];

function sinigangbaboyNext(){
  sinbaboyIP = (sinbaboyIP + 1) % sinigangbaboy.length;
  document.getElementById("sinigangbaboyIngproc").innerHTML =  sinigangbaboy[sinbaboyIP];
}


/*Batchoy */
let  batchoyIP = 1;
const batchoybatchoy = [ 
  "Ingredients:<br><ul>  <li> Pork organs (liver, heart, kidneys)</li>   <li>Miki noodles</li>   <li>Pork belly, sliced</li>   <li>Garlic, minced</li>   <li>Onion, chopped</li>   <li>Fish sauce (patis)</li>   <li>Beef or pork broth</li>   <li>Chicharrón (crispy pork skin) for garnish</li>   <li>Boiled egg for garnish</li>   </ul>",
  "Procedures:<br><ol>  <li>Saute minced garlic and chopped onion. Add sliced<br> pork belly, cook until browned (15-20 minutes).</li>   <li>Incorporate pork organs (liver, heart, kidneys), cook<br> until done (15 minutes).</li>    <li>Pour beef or pork broth, simmer. Add Miki noodles<br> and cook for 10-15 minutes.</li>    <li>Season with fish sauce (patis) according to taste.</li>    <li>Serve hot, garnished with chicharrón and a boiled egg.</li>    </ol>",
  "Please click the button to proceed,"
];

function batchoyNext(){
  batchoyIP = (batchoyIP + 1) % batchoybatchoy.length;
  document.getElementById("batchoyIngproc").innerHTML =  batchoybatchoy[batchoyIP];
}


/*Bulalo*/

let  bulaloIP = 1;
const bulalo = [ 
  "Ingredients:<br><ul>  <li>Beef shank with bone marrow</li>    <li>Corn on the cob</li>     <li>Banana hearts</li>     <li>Potatoes</li>     <li>Green onions</li>     <li>Fish sauce (patis)</li>   </ul>",
  "Procedures:<br><ol>  <li>Boil beef shank until tender, skimming off impurities (1.5 - 2 hours).</li>   <li>Add corn on the cob, banana hearts, and potatoes. Simmer for 20-30 minutes.</li>    <li>Season with fish sauce (patis) and garnish with green onions.</li>    <li>Serve hot.</li>    </ol>",
  "Please click the button to proceed,"
];

function bulaloNext(){
  bulaloIP = (bulaloIP + 1) % bulalo.length;
  document.getElementById("bulaloIngproc").innerHTML =  bulalo[bulaloIP];
}

/*La Paz Batchoy*/

let  lapazIP = 1;
const lapazbatchoy = [ 
  "Ingredients:<br><ul>  <li>Miki noodles</li>   <li>Pork belly, sliced</li>   <li>Pork liver, sliced</li>   <li>Garlic, minced</li>   <li>Chicharrón (crispy pork skin)</li>   <li>Boiled egg</li>   </ul>",
  "Procedures:<br><ol>  <li>Cook Miki noodles in broth with sliced pork belly (15-20 minutes).</li>    <li>Add minced garlic and sliced pork liver, continue cooking (10-15 minutes).</li>    <li>Top with chicharrón and a boiled egg.</li>    <li>Serve hot.</li>   </ol>",
  "Please click the button to proceed,"
];

function lapazNext(){
  lapazIP = (lapazIP + 1) % lapazbatchoy.length;
  document.getElementById("lapazIngproc").innerHTML =  lapazbatchoy[lapazIP];
}

/*Tinolang Isda */
let  tinolaisdaIP = 1;
const tinolangIsda = [ 
  "Ingredients:<br><ul>  <li>Fish (tilapia or any white fish)</li>    <li>Ginger, sliced</li>    <li>Garlic, minced</li>    <li>Chayote (sayote) or green papaya, sliced</li>    <li>Malunggay leaves</li>   </ul>",
  "Procedures:<br><ol>  <li>Sauté sliced ginger and minced garlic in a pot (10-15 minutes).</li>   <li>Add fish, cook until slightly browned.</li>   <li>Pour water, add chayote or green papaya, and simmer.</li>   <li>Add malunggay leaves and season to taste.</li>   <li>Serve hot.</li> </ol>",
  "Please click the button to proceed,"
];

function tinolaIsdaNext(){
  tinolaisdaIP = (tinolaisdaIP + 1) % tinolangIsda.length;
  document.getElementById("tinolaisdaIngproc").innerHTML =  tinolangIsda[tinolaisdaIP];
}


/*LUZON'S SIDE DISHES */

/*Laing */
let  laingIP = 1;
const laing = [ 
   "Ingredients:<br>  <ul> <li>Dried taro leaves</li>   <li>Coconut milk</li>   <li>Pork belly, sliced</li>   <li>Shrimp paste (bagoong)</li>   <li>Chili pepperss</li>   </ul>",
   "Procedures:<br>   <ol> <li>In a pot, combine dried taro leaves, coconut milk, sliced<br> pork belly, and shrimp paste according to taste.</li>  <li>Add chili peppers for spiciness, adjusting to your preference.</li>  <li>Cook over medium heat for approximately 30-40 minutes until the pork is tender and the coconut milk is reduced.</li>  <li>Stir occasionally to prevent sticking.</li>  <li>Serve this flavorful Laing as a side dish with rice.</li>   </ul>",
   "Please click the button to proceed,"
];

function laingNext(){
  laingIP = (laingIP + 1) % laing.length;
  document.getElementById("laingIngproc").innerHTML =  laing[laingIP];
}

/*Pinakbet*/

let  pakbetIP = 1;
const pinakbet = [ 
   "Ingredients:<br>  <ul> <li>Mixed vegetables (squash, eggplant, okra, string beans)</li>  <li>Bagoong (fermented shrimp paste)</li>  <li> Pork belly, sliced</li>  <li>Tomatoes, sliced</li>   </ul>",
   "Procedures:<br>   <ol> <li>In a pan, sauté sliced pork belly until lightly browned for about 10 minutes.</li>  <li> Add sliced tomatoes and continue cooking until softened.</li>  <li>Add mixed vegetables and cook until they are tender yet still crisp, approximately 15-20 minutes.</li>  <li>Incorporate bagoong according to taste, stirring well.</li>  <li>Cook until the vegetables are fully cooked but still vibrant in color.</li>  <li>Serve this savory Pinakbet as a delicious side dish.</li>   </ul>",
   "Please click the button to proceed,"
];

function pakbetNext(){
  pakbetIP = (pakbetIP + 1) % pinakbet.length;
  document.getElementById("pakbetIngproc").innerHTML =  pinakbet[pakbetIP];
}

/*Ginataang Gulay*/

let  ginataangIP = 1;
const ginataanGulay = [ 
   "Ingredients:<br>  <ul> <li>Mixed vegetables (squash, string beans, malunggay leaves)</li>   <li>Coconut milk</li>   <li>Shrimp or fish sauce</li>   <li>Garlic, minced</li>   </ul>",
   "Procedures:<br>   <ol> <li>In a pot, combine mixed vegetables, coconut milk, and minced garlic.</li>   <li>Season with shrimp or fish sauce according to taste.</li>   <li>Cook over medium heat until the vegetables are tender, approximately 15-20 minutes.</li>   <li>Stir occasionally to ensure even cooking.</li>   <li>Serve this creamy Ginataang Gulay as a delightful side dish. </li>  </ul>",
   "Please click the button to proceed,"
];

function ginataangNext(){
  ginataangIP= (ginataangIP + 1) % ginataanGulay.length;
  document.getElementById("ginataangIngproc").innerHTML =  ginataanGulay[ginataangIP];
}

/*Adobong Kangkongs*/

let  adokongIP = 1;
const adobongKangkong = [ 
   "Ingredients:<br>  <ul> <li>Kangkong (water spinach), chopped</li>   <li>Soy sauce</li>   <li>Vinegar</li>   <li>Garlic, minced</li>   <li>Pork or shrimp (optional)</li>   </ul>",
   "Procedures:<br>   <ol> <li> In a pan, sauté minced garlic until fragrant for about 5 minutes.</li>  <li>Add pork or shrimp (if using) and cook until browned.</li>  <li>Incorporate chopped kangkong and stir well.</li>  <li>Pour soy sauce and vinegar according to taste.</li>  <li>Cook until kangkong is wilted but still vibrant green, approximately 10-15 minutes.</li>  <li>Serve this flavorful Adobong Kangkong as a tasty side dish.</li>   </ul>",
   "Please click the button to proceed,"
];

function adokongNext(){
  adokongIP= (adokongIP + 1) % adobongKangkong.length;
  document.getElementById("adokongIngproc").innerHTML = adobongKangkong[adokongIP];
}

/*Tinolang Manoks */

let  tinolangmanokIP = 1;
const tinolangManok = [ 
   "Ingredients:<br>  <ul> <li>Chicken pieces</li>  <li>Ginger, sliced</li>  <li>Malunggay leaves</li>  <li>Fish sauce</li>  <li>Green papaya, sliced</li>   </ul>",
   "Procedures:<br>   <ol> <li>In a pot, sauté sliced ginger until aromatic for about 5 minutes.</li>  <li>Add chicken pieces and cook until lightly browned for approximately 10 minutes.</li>  <li> Pour enough water to cover the chicken and bring to a boil.</li>  <li> Add fish sauce according to taste.</li>  <li> Once the chicken is nearly cooked, add sliced green papaya.</li>  <li>Simmer until the papaya is tender, approximately 15-20 minutes.</li>  <li>Add malunggay leaves and cook until they are wilted for about 5 minutes.</li>  <li>Serve this nourishing Tinolang Manok as a comforting side dish.</li>   </ul>",
   "These detailed procedures include approximate cooking times to guide you through preparing these delicious Luzon side dishes. Enjoy cooking and savoring these Filipino flavors!🤣",
   "Please click the button to proceed,"
];

function tinolangmanokNext(){
   tinolangmanokIP= (tinolangmanokIP + 1) % tinolangManok.length;
  document.getElementById("tinolangmanokIngproc").innerHTML =  tinolangManok[tinolangmanokIP];
}


//Search Bar ambot lang ba kahag pwede nani sa tanan

function searchSection(){
  const query = document.getElementById('search').value.toLowerCase().trim();
  
  if(query === "")
  return;
  const sections = document.querySelectorAll('section');
  let matchFound = false;

  //Removing previous higlights!

  document.querySelectorAll('mark').forEach((mark) => mark.outerHTML = mark.textContent);


 sections.forEach((section) => {
  const texts = section.querySelectorAll('h2, p');
  texts.forEach((text)=> {
      const originalText = text.textContent;
      const newText = originalText.replace(new RegExp(query, 'gi'), match => `<mark>${match}</mark>`);

      if(newText!==originalText){
          text.innerHTML = newText;
          text.parentNode.scrollIntoView({behavior: 'smooth'});
          matchFound = true;
      }
  });
 });

 if(!matchFound){
  document.getElementById('result').innerHTML = "Word doesn't match";



  document.querySelectorAll('mark').forEach((mark) => mark.outerHTML = mark.textContent);
  
 } else {
  document.getElementById('result').innerHTML = "";
 }
    
}
